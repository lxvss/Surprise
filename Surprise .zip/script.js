// =============================
// Birthday Website - Script.js
// By Lavanya ❤️
// =============================

// Open Popup
const openBtn = document.getElementById("openBtn");
const popup = document.getElementById("popup");

if (openBtn && popup) {
    openBtn.addEventListener("click", () => {
        popup.style.display = "flex";
    });
}


// Continue Button
function nextPage() {
    document.body.style.transition = "1s";
    document.body.style.opacity = "0";

    setTimeout(() => {
        window.location.href = "loveletter.html";
    }, 1000);
}


// Floating Hearts
function createHeart() {
    const heart = document.createElement("div");

    heart.innerHTML = "❤️";
    heart.style.position = "fixed";
    heart.style.left = Math.random() * window.innerWidth + "px";
    heart.style.top = "-20px";
    heart.style.fontSize = (20 + Math.random() * 20) + "px";
    heart.style.animation = "fall 6s linear forwards";
    heart.style.zIndex = "999";

    document.body.appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 6000);
}

setInterval(createHeart, 500);


// Falling Animation
const style = document.createElement("style");

style.innerHTML = `
@keyframes fall {
    0% {
        transform: translateY(-50px) rotate(0deg);
        opacity: 1;
    }

    100% {
        transform: translateY(110vh) rotate(360deg);
        opacity: 0;
    }
}
`;

document.head.appendChild(style);


// Welcome Message
setTimeout(() => {
    console.log("Happy Birthday Saran ❤️");
}, 1000);


// ===============================
// Romantic Effects ❤️
// ===============================

// Mouse Hearts
document.addEventListener("mousemove", function(e) {

    const heart = document.createElement("span");

    heart.innerHTML = "💖";
    heart.style.position = "fixed";
    heart.style.left = e.clientX + "px";
    heart.style.top = e.clientY + "px";
    heart.style.pointerEvents = "none";
    heart.style.fontSize = "18px";
    heart.style.zIndex = "9999";
    heart.style.transition = "1s";

    document.body.appendChild(heart);

    setTimeout(() => {
        heart.style.transform = "translateY(-40px) scale(1.8)";
        heart.style.opacity = "0";
    }, 50);

    setTimeout(() => {
        heart.remove();
    }, 1000);

});


// Greeting Popup
setTimeout(() => {
    alert("❤️ Happiest Birthday Saran Maaaa ❤️");
}, 3000);


// Background Color Change
const colors = [
    "#fff0f6",
    "#ffe4ec",
    "#ffd6e8",
    "#ffeaf4"
];

let i = 0;

setInterval(() => {

    document.body.style.background = colors[i];

    i++;

    if (i >= colors.length) {
        i = 0;
    }

}, 5000);


// Typing Console Message
const msg = "Made with Love by Lavanya ❤️";

let index = 0;

function typing() {

    if (index < msg.length) {

        console.log(msg.charAt(index));

        index++;

        setTimeout(typing, 100);
    }
}

typing();


// Button Glow
const btn = document.getElementById("openBtn");

if (btn) {

    setInterval(() => {

        btn.style.boxShadow = "0 0 30px hotpink";

        setTimeout(() => {
            btn.style.boxShadow = "0 0 10px pink";
        }, 600);

    }, 1200);

}


// Love Quotes
const quotes = [

    "You are my favorite person ❤️",
    "I'll always choose you ❤️",
    "Forever starts with you ❤️",
    "My happiness begins with you ❤️"

];

setInterval(() => {

    const random = Math.floor(Math.random() * quotes.length);

    document.title = quotes[random];

}, 4000);
let foundHearts = 0;

function findHeart(heart){

    if(heart.classList.contains("found")){
        return;
    }

    heart.classList.add("found");

    foundHearts++;

    document.getElementById("gameMessage").innerHTML =
        "Found: " + foundHearts + " / 3 💕";

    if(foundHearts === 3){

        document.getElementById("gameMessage").innerHTML =
            "🎉 You found my heart! ❤️ Surprise unlocked!";

        const openBtn = document.getElementById("openBtn");

        openBtn.disabled = false;
        openBtn.style.opacity = "1";
        openBtn.style.pointerEvents = "auto";
    }
}